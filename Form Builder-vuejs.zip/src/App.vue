<script setup lang="ts">
import MultiStepForm from "./components/MultiStepForm.vue";
</script>

<template>
	<div id="app">
		<MultiStepForm />
	</div>
</template>
